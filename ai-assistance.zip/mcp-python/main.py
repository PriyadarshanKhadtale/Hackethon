import os
import asyncio
from dotenv import load_dotenv
from agents import Agent, Runner, set_tracing_disabled
from agents.extensions.models.litellm_model import LitellmModel
from agents.mcp import MCPServerStdio

load_dotenv(override=True)
set_tracing_disabled(True)

fetch_params = {
    "command": "uv",
    "args": ["run", "/Users/amit.chauhan/Desktop/My Learning/mcp-server-python/server.py"],
}


async def main():
    async with MCPServerStdio(params=fetch_params, client_session_timeout_seconds=30) as server:
        chat_agent = Agent(
            name="Developer AI Assistant",
            instructions="You are a helpful assistant that can help with coding tasks.",
            model=LitellmModel(
                model="github/gpt-4o-mini",
                api_key=os.getenv("GITHUB_TOKEN"),
            ),
            mcp_servers=[server],
        )

        while True:
            message = input("Enter your prompt: ")
            result = await Runner.run(chat_agent, message)
            print("AI response:", result.final_output)
            print("--------------------------------")


if __name__ == "__main__":
    asyncio.run(main())
