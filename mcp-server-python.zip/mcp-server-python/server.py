from pathlib import Path
from typing import Optional
from uuid import uuid4

from dotenv import load_dotenv
from mcp.server.fastmcp import FastMCP
import json

load_dotenv("./env")

DATA_PATH = Path(__file__).parent.resolve() / "data/user.json"


def _ensure_store() -> None:
    DATA_PATH.parent.mkdir(parents=True, exist_ok=True)
    if not DATA_PATH.exists():
        DATA_PATH.write_text("[]", encoding="utf-8")


def _load_users() -> list[dict]:
    _ensure_store()
    with DATA_PATH.open("r", encoding="utf-8") as f:
        return json.load(f)


def _save_users(users: list[dict]) -> None:
    with DATA_PATH.open("w", encoding="utf-8") as f:
        json.dump(users, f, indent=2)


mcp = FastMCP(
    name="UserRegistry",
    host="0.0.0.0",
    port=8050,
)


def _find_user(users: list[dict], user_id: str) -> Optional[dict]:
    return next((user for user in users if user["id"] == user_id), None)


@mcp.tool()
def create_user(name: str, description: str) -> dict:
    """
    Create a new user and return the stored record.
    """
    users = _load_users()
    user = {
        "id": str(uuid4()),
        "name": name,
        "description": description,
    }
    users.append(user)
    _save_users(users)
    return user


@mcp.tool()
def read_user(user_id: str) -> dict:
    """
    Return a user by ID.
    """
    users = _load_users()
    user = _find_user(users, user_id)
    if user is None:
        return {"error": "User not found"}
    return user


@mcp.tool()
def update_user(user_id: str, name: Optional[str] = None, description: Optional[str] = None) -> dict:
    """
    Update an existing user fields if provided.
    """
    users = _load_users()
    user = _find_user(users, user_id)
    if user is None:
        return {"error": "User not found"}

    if name is not None:
        user["name"] = name
    if description is not None:
        user["description"] = description

    _save_users(users)
    return user


@mcp.tool()
def delete_user(user_id: str) -> dict:
    """
    Delete a user by ID.
    """
    users = _load_users()
    user = _find_user(users, user_id)
    if user is None:
        return {"error": "User not found"}

    users = [u for u in users if u["id"] != user_id]
    _save_users(users)
    return {"status": "deleted", "id": user_id}

if __name__ == "__main__":
    transport = "stdio"

    if transport == "stdio":
        print("Running serve in stdio mode")
        mcp.run(transport)
    elif transport == "sse":
        print("Running serve in sse mode")
        mcp.run(transport)
    else:
        raise ValueError (f"Unknown transport: {transport}")